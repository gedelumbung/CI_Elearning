using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Suryo_C_Sharp__part3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Mahasiswa mhs = new Mahasiswa(); // membuat object mhs
            Mahasiswa mhs2 = new Mahasiswa(); // membuat object mhs2
            Mahasiswa mhs3 = new Mahasiswa(); // membuat object mhs3
            
            mhs.mahasiswaMemberFunction();  
            //memanggil function dari mhs, function ini dapat kita panggil
            //karena function ini tidak memiliki static
            //karena itu mhs sebagai member(object yg dibuat dari Mahasiswa)
            //dapat memanggil function tersebut

            //cobalah untuk memanggil mhs.mahasiswaClassFunction
            //lines ini tidak akan dapat dipanggil / dicompile karena memiliki
            //keyword "Static" di depan functionnnya dan kita hanya dapat 
            //memanggilnya melewati class itu sendiri dan tidak dapat mengakses
            //melewati object / member yang telah dibuat
            //jadi untuk memanggilnya kita langsung melewati classnya
            //seperti berikut ini :

            Mahasiswa.mahasiswaClassFunction(); //via class dapat mengakses
            //mhs.mahasiswaClassFunction  //via object tidak dapat mengakses

            mhs.nNilai =  5 ; // via member 
            Mahasiswa.nStaticNilai = 100; // via class

            Console.Write("Masukkan nama mahasiswa pertama   : ");
            string mhs2Nama = Console.ReadLine();
            
            
            string mhs2Nilai1  ;
            do
            {
              Console.Write("Masukkan nilai pertama (max 100)  : ");
              mhs2Nilai1 = Console.ReadLine();
            } while (Convert.ToInt16(mhs2Nilai1) > 100);

            string mhs2Nilai2;
            do
            {
              Console.Write("Masukkan nilai kedua   (max 100)  : ");
              mhs2Nilai2 = Console.ReadLine();
            } while (Convert.ToInt16(mhs2Nilai2) > 100);

            mhs2.nama = mhs2Nama;
            mhs2.nilaiUjian1 = Convert.ToInt16(mhs2Nilai1) ;
            mhs2.nilaiUjian2 = Convert.ToInt16(mhs2Nilai2) ;

            Console.Write("Masukkan nama mahasiswa kedua     : ");
            string mhs3Nama = Console.ReadLine();
            string mhs3Nilai1;
            do
            {
                Console.Write("Masukkan nilai pertama (max 100)  : ");
                mhs3Nilai1 = Console.ReadLine();
            } while (Convert.ToInt16(mhs3Nilai1) > 100);

            string mhs3Nilai2;
            do
            {
                Console.Write("Masukkan nilai kedua   (max 100)  : ");
                mhs3Nilai2 = Console.ReadLine();
            } while (Convert.ToInt16(mhs3Nilai2) > 100);

            mhs3.nama = mhs3Nama;
            mhs3.nilaiUjian1 = Convert.ToInt16(mhs3Nilai1);
            mhs3.nilaiUjian2 = Convert.ToInt16(mhs3Nilai2);
            int no = 1;
            mhs2.hitungNilai(ref mhs2.nilaiUjian1, ref mhs2.nilaiUjian2 , ref no);
            no++;
            mhs3.hitungNilai(ref mhs3.nilaiUjian1, ref mhs3.nilaiUjian2 , ref no);  

        }
    }
}