using System;
using System.Collections.Generic;
using System.Text;

namespace Suryo_C_Sharp__part3
{
    class Mahasiswa
    {
        public string nama = "";
        public double nNilai  ; // non-static
        public static double nStaticNilai;// static
        public static int Nomor = 0 ;
        public int nilaiUjian1 = 0  ;
        public int nilaiUjian2 = 0 ;
        public void mahasiswaMemberFunction() // non-static
        {
        Console.WriteLine("mahasiswa member function");
        }

        public static void mahasiswaClassFunction() // static
        {
        Console.WriteLine("mahasiswa class function");
        }

        public void hitungNilai(ref int a, ref int b , ref int no) // non-static
        {
            nNilai++; 
            Console.WriteLine("\n");
            nStaticNilai = Convert.ToDouble(a) / Convert.ToDouble(b);
            Console.WriteLine("Nilai rata2 mahasiswa ke " + no + " : " + nStaticNilai);
        }
    }
}
