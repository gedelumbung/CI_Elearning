namespace Suryo_C_Sharp__part1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_Timer1 = new System.Windows.Forms.Label();
            this.lbl_Timer2 = new System.Windows.Forms.Label();
            this.lbl_Hasil = new System.Windows.Forms.Label();
            this.lbl_Plus = new System.Windows.Forms.Label();
            this.lbl_Equal = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl_belajar = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_Timer1
            // 
            this.lbl_Timer1.AutoSize = true;
            this.lbl_Timer1.Location = new System.Drawing.Point(14, 12);
            this.lbl_Timer1.Name = "lbl_Timer1";
            this.lbl_Timer1.Size = new System.Drawing.Size(65, 13);
            this.lbl_Timer1.TabIndex = 0;
            this.lbl_Timer1.Text = "Nilai Timer 1";
            // 
            // lbl_Timer2
            // 
            this.lbl_Timer2.AutoSize = true;
            this.lbl_Timer2.Location = new System.Drawing.Point(104, 12);
            this.lbl_Timer2.Name = "lbl_Timer2";
            this.lbl_Timer2.Size = new System.Drawing.Size(65, 13);
            this.lbl_Timer2.TabIndex = 1;
            this.lbl_Timer2.Text = "Nilai Timer 2";
            // 
            // lbl_Hasil
            // 
            this.lbl_Hasil.AutoSize = true;
            this.lbl_Hasil.Location = new System.Drawing.Point(197, 12);
            this.lbl_Hasil.Name = "lbl_Hasil";
            this.lbl_Hasil.Size = new System.Drawing.Size(60, 13);
            this.lbl_Hasil.TabIndex = 2;
            this.lbl_Hasil.Text = "Timer 1 + 2";
            // 
            // lbl_Plus
            // 
            this.lbl_Plus.AutoSize = true;
            this.lbl_Plus.Location = new System.Drawing.Point(85, 12);
            this.lbl_Plus.Name = "lbl_Plus";
            this.lbl_Plus.Size = new System.Drawing.Size(13, 13);
            this.lbl_Plus.TabIndex = 3;
            this.lbl_Plus.Text = "+";
            // 
            // lbl_Equal
            // 
            this.lbl_Equal.AutoSize = true;
            this.lbl_Equal.Location = new System.Drawing.Point(178, 12);
            this.lbl_Equal.Name = "lbl_Equal";
            this.lbl_Equal.Size = new System.Drawing.Size(13, 13);
            this.lbl_Equal.TabIndex = 4;
            this.lbl_Equal.Text = "=";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl_belajar
            // 
            this.lbl_belajar.AutoSize = true;
            this.lbl_belajar.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_belajar.Location = new System.Drawing.Point(7, 43);
            this.lbl_belajar.Name = "lbl_belajar";
            this.lbl_belajar.Size = new System.Drawing.Size(261, 25);
            this.lbl_belajar.TabIndex = 5;
            this.lbl_belajar.Text = "BELAJAR C# ITU MUDAH";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 81);
            this.Controls.Add(this.lbl_belajar);
            this.Controls.Add(this.lbl_Equal);
            this.Controls.Add(this.lbl_Plus);
            this.Controls.Add(this.lbl_Hasil);
            this.Controls.Add(this.lbl_Timer2);
            this.Controls.Add(this.lbl_Timer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Timer1;
        private System.Windows.Forms.Label lbl_Timer2;
        private System.Windows.Forms.Label lbl_Hasil;
        private System.Windows.Forms.Label lbl_Plus;
        private System.Windows.Forms.Label lbl_Equal;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl_belajar;
    }
}

