using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Suryo_C_Sharp__part1
{
    public partial class Form1 : Form
    {
        //variabel nilai awal untuk lbl_timer1 dan lbl_timer2 sebelum dijumlah
        int a = 0;
        int b = 0;
        //membuat variabel bertipe string dan menampung kalimat ke dalamnya
        string kata = "BELAJAR C# ITU MUDAH";
        //variabel panjang dan nilai awal mula-mula
        int panjang = 0;
        int nilai_awal = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Mencari Panjang dari kalimat "BELAJAR C# ITU MUDAH"
            panjang = Convert.ToInt16(kata.Length);
            //variabel a ditambah 5 , dan b ditambah 10
            a = a + 5;
            b = b + 10;
            //ganti nilai dari masing2 Label sesuai variabel
            lbl_Timer1.Text = Convert.ToString(a);
            lbl_Timer2.Text = Convert.ToString(b);
            lbl_Hasil.Text = Convert.ToString(a + b);
            //reset nilai ketika variabel bernilai sama
            if (nilai_awal == panjang)
            {
                nilai_awal = 0;
            }           
            //ambil kalimat sesuai indexnya untuk ditampilkan ke dalam label
            lbl_belajar.Text = kata.Substring(nilai_awal, panjang - nilai_awal); 
            //variabel nilai awal di tambah 1
            nilai_awal = nilai_awal + 1;           
        }
        private void Form1_Load(object sender, EventArgs e)
        {
         
        }
    }
}