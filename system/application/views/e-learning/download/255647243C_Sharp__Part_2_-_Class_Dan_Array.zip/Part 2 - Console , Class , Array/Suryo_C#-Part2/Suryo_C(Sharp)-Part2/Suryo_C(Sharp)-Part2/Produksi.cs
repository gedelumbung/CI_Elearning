using System;
using System.Collections.Generic;
using System.Text;

namespace Suryo_C_Sharp__Part2
{
    class Produksi
    {
        public int tahunProduksi;
    }
}
