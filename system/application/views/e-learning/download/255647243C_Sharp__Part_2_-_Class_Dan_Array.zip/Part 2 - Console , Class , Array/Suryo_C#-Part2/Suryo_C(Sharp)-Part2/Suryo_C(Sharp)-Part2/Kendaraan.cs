using System;
using System.Collections.Generic;
using System.Text;

namespace Suryo_C_Sharp__Part2
{
    class Kendaraan
    {
        public string PlatNomor ; 
        public string Model ;
        public string Manufaktur ; 
        public int SpeedMax ;
        public Produksi keteranganMobil ;
    }
}
