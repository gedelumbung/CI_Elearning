using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Suryo_C_Sharp__Part2
{
    public partial class Form1 : Form
    {
        public class pembeli
        {
            public string nama ;
            public double harga ;             
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {      
            Kendaraan mobilPertamaku;
            mobilPertamaku = new Kendaraan();

            mobilPertamaku.PlatNomor = "BE 71 AA" ;
            mobilPertamaku.Model = "Suzuki New Baleno" ;
            mobilPertamaku.SpeedMax = 160  ;
            mobilPertamaku.Manufaktur = "Suzuki";

            Console.WriteLine("Mobilku : " + mobilPertamaku.Model + ", Buatan : " + mobilPertamaku.Manufaktur +
                "\n" + "Memiliki kecepatan : " + mobilPertamaku.SpeedMax + "\n" + "Dan memiliki Plat Nomor : " + mobilPertamaku.PlatNomor ); 

            Kendaraan MobilCoklat = mobilPertamaku ;
            MobilCoklat.Model = "Suzuki APV" ;
            Console.Write("\n");
            Console.WriteLine("Mobil pertamaku adalah : " + mobilPertamaku.Model);

            mobilPertamaku = null;
            MobilCoklat.Model = "Suzuki APV";
            Console.WriteLine("Mobil Coklat pertamaku adalah : " + MobilCoklat.Model);

            Produksi YearProduct = new Produksi();
            YearProduct.tahunProduksi = 2004;
            MobilCoklat.keteranganMobil = YearProduct;
            Console.WriteLine("Tahun Produksi : " + Convert.ToString(MobilCoklat.keteranganMobil.tahunProduksi + "\n"));
            
            Console.Write("Masukkan jumlah pembeli : ");
            string Pembeli = Console.ReadLine();
            int jumlahPembeli = Convert.ToInt32(Pembeli);
            pembeli[] listPembeli = new pembeli[jumlahPembeli];
            
            for (int i = 0; i < listPembeli.Length; i++)
            {
                Console.Write("Pembeli ke " + (i + 1) + "  : ");
                string NamaPembeli = Console.ReadLine();
                Console.Write("Tawaran Harga : ");
                string hargaTawaran = Console.ReadLine();
                double convertHargaTawaran = Convert.ToDouble(hargaTawaran);
                pembeli thisBuyer = new pembeli();
                thisBuyer.nama = NamaPembeli;
                thisBuyer.harga = convertHargaTawaran; 
                listPembeli[i] = thisBuyer ; 
                
            }

            Console.Write("\n");
            foreach (pembeli i in listPembeli)
            {
                System.Console.WriteLine("Pembeli dengan nama " + i.nama + " berani membeli dengan harga : " + i.harga);
            }
        }
    }
}